#include "stdafx.h"
#include "Constant.h"

namespace Constant
{
	namespace Database
	{
		const std::tstring DB_ROOT = _T("db/");
		const std::tstring USER_INFO_FILE_NAME = _T("UserInfo.xml");
	}
}