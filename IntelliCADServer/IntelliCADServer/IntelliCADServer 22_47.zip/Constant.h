#pragma once

#include "tstring.h"

namespace Constant
{
	namespace Database
	{
		extern const std::tstring DB_ROOT;
		extern const std::tstring USER_INFO_FILE_NAME;
	}
}