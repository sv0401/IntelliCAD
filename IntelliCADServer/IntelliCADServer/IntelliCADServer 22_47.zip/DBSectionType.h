#pragma once

enum DBSectionType
{
	USER, CT_IMAGE, DOCUMENT
};
