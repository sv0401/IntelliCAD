#pragma warning(disable:4996)

#include "stdafx.h"
#include "DatabaseManager.h"
#include "Constant.h"

using namespace std;
using namespace std::experimental::filesystem;
using namespace tinyxml2; 

DatabaseManager::DatabaseManager(const tstring &rootPath, const bool creating)
{
	//rootPath�� �°� db��ġ ����
	this->__rootPath = rootPath;
}

bool DatabaseManager::load(const tstring &rootPath, const bool creating)
{
	this->__rootPath = rootPath;
	//���� ��θ�
	string csRoot = Parser::tstring$string(rootPath);
	string csUser = Parser::tstring$string(__userPath);
	string csCT = Parser::tstring$string(__ctImagePath);
	string csDoc = Parser::tstring$string(__documentPath);

	string csUserPath = csRoot;
	csUserPath.append(csUser);

	string csCTPath = csRoot;
	csCTPath.append(csCT);

	string csDocPath = csRoot;
	csDocPath.append(csDoc);

	//���� �����ϱ�
	for (int i = 0; i < 3; i++)
	{
		string path;
		string tmp;
		switch (i)
		{
		case 0: path = csUserPath; break;
		case 1: path = csCTPath; break;
		case 2: path = csDocPath; break;
		}
		
		int index = 0;

		while (true)
		{
			index = path.find("/");
			tmp += path.substr(0, index) + "/";
			CreateDirectory(CA2CT(tmp.c_str()), NULL);
			path = path.substr(index + 1, path.length());

			if (index < 0) break;
		}
	}
	if (!_tcscmp(__rootPath.c_str(), _T("")))
		return false;
	else
		return true;
}

bool DatabaseManager::isLoaded() const
{
	// �����ʿ�
	if (!_tcscmp(__rootPath.c_str(), _T("")))
		return false;
	else
		return true;
}

const tstring &DatabaseManager::getRootPath() const
{
	return __rootPath;
}

const tstring &DatabaseManager::getSectionPath(const DBSectionType sectionType) const
{
	tstring csRoot = __rootPath;
	tstring csUser = __userPath;
	tstring csCT = __ctImagePath;
	tstring csDoc = __documentPath;

	tstring csUserPath = csRoot;
	csUserPath.append(csUser);
	static const tstring userPath = csUserPath;

	tstring csCTPath = csRoot;
	csCTPath.append(csCT);
	static const tstring ctPath = csCTPath;

	tstring csDocPath = csRoot;
	csDocPath.append(csDoc);
	static const tstring docPath = csDocPath;

	switch (sectionType)
	{
	case DBSectionType::USER: return userPath;
	case DBSectionType::CT_IMAGE: return ctPath;
	case DBSectionType::DOCUMENT: return docPath;
	}
}

bool DatabaseManager::move(const tstring &newRootPath)
{
	int ret = rename(Parser::tstring$string(__rootPath).c_str(), Parser::tstring$string(newRootPath).c_str());
	if (ret != -1)
	{
		__rootPath = newRootPath;
		return true;
	}
	else
		return false;
}

bool DatabaseManager::copy(const tstring &targetRootPath)
{
	__copyAll(__rootPath, targetRootPath);
	return true;
}
bool DatabaseManager::__copyAll(const tstring &sourceRootPath, const tstring &targetRootPath)
{
	HANDLE hSrch;
	WIN32_FIND_DATA wfd;

	string fname;
	string src;
	string dec;
	string wildCard;
	bool result;

	//���� ���� ��θ�
	CString csRoot_o = Parser::tstring$CString(sourceRootPath);
	

	//�������� ��θ�-��ͷ� ���ð���
	CString csRoot = Parser::tstring$CString(targetRootPath);
	
	//�������� �����ϱ�
	
	int index = 0;

	string pathF = Parser::tstring$string(targetRootPath);
	string tmpF;
	while (true)
	{
		index = pathF.find("/");
		tmpF += pathF.substr(0, index) + "/";
		CreateDirectory(CA2CT(tmpF.c_str()), NULL);
		pathF = pathF.substr(index + 1, pathF.length());

		if (index < 0) break;
	}

	//sourceRootPath�� ��� �����͵��� wildCard�� ����
	wildCard = Parser::tstring$string(sourceRootPath);
	wildCard.append("*.*");
	//wildCard����� ���ϵ� ã�Ƽ� wfd����ü�� �ֱ�
	
	hSrch = FindFirstFile((CA2CT(wildCard.c_str())), &wfd);
	if (hSrch == INVALID_HANDLE_VALUE)
	{
		cout << sourceRootPath << ">>";
		cout << "NO ENTRY" << endl;
		return true;
	}
	result = true;
	while (result)
	{
		//dbRoot/������ ������ �ִٸ� ������ ��θ� �����
		path filePath_fo(csRoot_o.GetString());
		filePath_fo /= wfd.cFileName;
		fname = CT2CA(filePath_fo.c_str());

		//���� ��Ʈ���� dir�̸�
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			//���� ������ ���� ���� ����
			if (wfd.cFileName[0] != '.')
			{
				path filePath_o(csRoot_o.GetString());
				filePath_o /= wfd.cFileName;
				src = CT2CA(filePath_o.c_str());
				src.append("/");
				tstring t_src(src.begin(), src.end());
				
				path filePath_n(csRoot.GetString());
				filePath_n /= wfd.cFileName;
				dec = CT2CA(filePath_n.c_str());
				dec.append("/");
				tstring t_dec(dec.begin(), dec.end());
				__copyAll(t_src, t_dec);
			}
		}
		else
		{
			path filePath_f(csRoot.GetString());
			filePath_f /= wfd.cFileName;
			dec = CT2CA(filePath_f.c_str());
			CopyFile(CA2CT(fname.c_str()), CA2CT(dec.c_str()), FALSE);
		}
		//���� ���� ã��
		result = FindNextFile(hSrch, &wfd);
	}
	FindClose(hSrch);
		
	return true;
}
bool DatabaseManager::openFile(const std::tstring& fname, fstream& in) const
{
	tstring userFile = getSectionPath(DBSectionType::USER);
	userFile.append(fname);
	in.open(Parser::tstring$string(userFile));

	if (in.is_open())
		return true;
	else
		return false;
}

	
bool DatabaseManager::store() const
{
	return false;
}

bool DatabaseManager::close()
{
	return false;
}

bool DatabaseManager::__createUser(const UserInfo& userInfo, const string fname) 
{
	_wsetlocale(LC_ALL, L"korean");
	tstring userFile = getSectionPath(DBSectionType::USER);
	string s_userFile = Parser::tstring$string(userFile);
	s_userFile.append(fname);

	tinyxml2::XMLDocument doc;

	XMLNode *pRoot = doc.NewElement("Users");
	doc.LinkEndChild(pRoot);

	doc.SaveFile(s_userFile.c_str());

	return true;
}

bool DatabaseManager::__saveUser(const UserInfo &userInfo, const string fname)
{
	tinyxml2::XMLDocument doc;

	tstring userFile = getSectionPath(DBSectionType::USER);
	string s_userFile = Parser::tstring$string(userFile);
	s_userFile.append(fname);
	
	doc.LoadFile(s_userFile.c_str());

	XMLNode* pRoot = doc.FirstChild();
	
	XMLElement *userE = doc.NewElement("User");
	pRoot->LinkEndChild(userE);

	XMLElement* e_id = doc.NewElement("ID");
	tstring id = userInfo.id;
	string s_id = Parser::tstring$string(id);
	e_id->LinkEndChild(doc.NewText(s_id.c_str()));
	userE->LinkEndChild(e_id);

	XMLElement* e_pw = doc.NewElement("PW");
	tstring pw = userInfo.passwd;
	string s_pw = Parser::tstring$string(pw);
	e_pw->LinkEndChild(doc.NewText(s_pw.c_str()));
	userE->LinkEndChild(e_pw);

	XMLElement* e_name = doc.NewElement("NAME");
	tstring name = userInfo.name;
	string s_name = Parser::tstring$string(name);
	e_name->LinkEndChild(doc.NewText(s_name.c_str()));
	userE->LinkEndChild(e_name);

	XMLElement* e_gender = doc.NewElement("GENDER");
	tstring gender = userInfo.gender;
	string s_gender = Parser::tstring$string(gender);
	e_gender->LinkEndChild(doc.NewText(s_gender.c_str()));
	userE->LinkEndChild(e_gender);

	XMLElement* e_age = doc.NewElement("AGE");
	tstring age = userInfo.age;
	string s_age = Parser::tstring$string(age);
	e_age->LinkEndChild(doc.NewText(s_age.c_str()));
	userE->LinkEndChild(e_age);

	doc.SaveFile(s_userFile.c_str());
	
	return true;
}

bool DatabaseManager::findId(const tstring& id)
{
	tinyxml2::XMLDocument doc;
	const XMLNode* userNode;
	const XMLNode* elem;

	tstring userFile = getSectionPath(DBSectionType::USER);
	string s_userFile = Parser::tstring$string(userFile);
	// string fname = "UserInfo.xml";
	string fname = Parser::tstring$string(Constant::Database::USER_INFO_FILE_NAME);
	s_userFile.append(fname);
	
	doc.LoadFile(s_userFile.c_str());
	const XMLNode* pRoot = doc.FirstChild();

	for (userNode = static_cast<const XMLNode *>(pRoot->FirstChild()); userNode != 0; userNode = (XMLNode*)userNode->NextSibling())
	{
		elem = userNode->FirstChild();
		tstring tmpId = Parser::charString$tstring(elem->FirstChild()->Value());
		if (_tcscmp(id.c_str(), tmpId.c_str()) == 0)
		{
			return true;
		}
	}
	return false;
}

shared_ptr<UserInfo> DatabaseManager::getUserInfo(const tstring& id)
{
	tinyxml2::XMLDocument doc;
	const XMLNode* userNode;
	const XMLNode* idNode;
	const XMLNode* psNode;
	const XMLNode* nameNode;
	const XMLNode* genderNode;
	const XMLNode* ageNode;

	shared_ptr<UserInfo> retVal = nullptr;
	/*UserInfo user;

	user.id = _T("NOENT");
	user.passwd = _T("NOENT");
	user.name = _T("NOENT");
	user.gender= _T("NOENT");
	user.age = _T("NOENT");*/

	tstring userFile = getSectionPath(DBSectionType::USER);
	string s_userFile = Parser::tstring$string(userFile);
	// string fname = "UserInfo.xml";
	string fname = Parser::tstring$string(Constant::Database::USER_INFO_FILE_NAME);
	s_userFile.append(fname);

	doc.LoadFile(s_userFile.c_str());
	const XMLNode* pRoot = doc.FirstChild();

	for (userNode = static_cast<const XMLNode *>(pRoot->FirstChild()); userNode != 0; userNode = (XMLNode*)userNode->NextSibling())
	{
		idNode = userNode->FirstChild();
		tstring tmpId = Parser::charString$tstring(idNode->FirstChild()->Value());
		
		if (id == tmpId)
		{
			retVal = make_shared<UserInfo>();

			retVal->id = tmpId;
			
			psNode = idNode->NextSibling();
			retVal->passwd = Parser::charString$tstring(psNode->FirstChild()->Value());
		
			nameNode = psNode->NextSibling();
			retVal->name = Parser::charString$tstring(nameNode->FirstChild()->Value());

			genderNode = nameNode->NextSibling();
			retVal->gender = Parser::charString$tstring(genderNode->FirstChild()->Value());

			ageNode = genderNode->NextSibling();
			retVal->age = Parser::charString$tstring(ageNode->FirstChild()->Value());
			
			break;
		}
	}
	return retVal;
}

bool DatabaseManager::addUserInfo(const UserInfo& userInfo)
{
	tstring userFile = getSectionPath(DBSectionType::USER);
	string s_userFile = Parser::tstring$string(userFile);
	// string fname = "UserInfo.xml";
	string fname = Parser::tstring$string(Constant::Database::USER_INFO_FILE_NAME);
	
	if (FILE*fp = fopen(s_userFile.append(fname).c_str(),"r"))
	{
		fclose(fp);
		
		if (!findId(userInfo.id))
		{
			if (!__saveUser(userInfo, fname))
				return false;
			else
				return true;
		}
		cout << "already exist id" << endl;
		return false;
	}
	else
	{
		if (__createUser(userInfo, fname))
		{
			if (!__saveUser(userInfo, fname))
				return false;
			return true;
		}
		else
			return false;
		
	}

	return true;
}
