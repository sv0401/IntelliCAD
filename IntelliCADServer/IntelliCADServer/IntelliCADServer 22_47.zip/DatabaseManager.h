#pragma once

#include "tstring.h"
#include "DBSectionType.h"

#include "tinyxml2.h"
#include "Parser.hpp"
#include "UserInfo.h"
#include <Windows.h>
#include <io.h>
#include <filesystem>
#include <iostream>
#include <sstream>
#include <fstream>
#include <locale.h>
#include <memory>

class DatabaseManager
{
private:
	std::tstring __rootPath;

	std::tstring __userPath = _T("user/");
	std::tstring __ctImagePath = _T("ct/");
	std::tstring __documentPath = _T("doc/");

	bool __copyAll(const std::tstring &sourceRootPath, const std::tstring &targetRootPath);//���
	
	bool __saveUser(const UserInfo &userInfo, const std::string fname);
	bool __createUser(const UserInfo& userInfo, const std::string fname);
	
public:
	DatabaseManager() = default;
	DatabaseManager(const std::tstring &rootPath, const bool creating = true);

	bool load(const std::tstring &rootPath, const bool creating = true);
	bool isLoaded() const;

	const std::tstring &getRootPath() const;
	const std::tstring &getSectionPath(const DBSectionType sectionType) const;

	bool move(const std::tstring &newRootPath);
	bool copy(const std::tstring &targetRootPath);

	bool openFile(const std::tstring& fname, std::fstream& in) const;

	bool store() const;
	bool close();

	bool addUserInfo(const UserInfo& userInfo);
	bool findId(const std::tstring& id);
	
	std::shared_ptr<UserInfo> getUserInfo(const std::tstring& id);
};
