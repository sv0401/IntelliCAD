#pragma once

#include <any>
#include <utility>
#include "TaskType.h"

using FinishedTask = std::pair<TaskType, std::any>;