/*
*	Copyright (C) 2019 APIless team. All right reserved.
*
*	���ϸ�			: System.cpp
*	�ۼ���			: �̼���
*	���� ������		: 19.03.22
*
*	�ý��� ���
*/

#include "stdafx.h"
#include "System.h"
#include "IntelliCADServerDlg.h"

using namespace std;

System System::__instance;

void System::__setDlgReference(CIntelliCADServerDlg &dlg)
{
	__pDlg = &dlg;
}

void System::__init()
{
	__instance.systemContents.__init();
}

void System::__release()
{
	__instance.systemContents.__release();
}

void System::SystemContents::__init()
{
	__pTaskMgr = new AsyncTaskManager();
	__pEventBroadcaster = new EventBroadcaster();
	__pDatabaseManager = new DatabaseManager();
	__pServerNetwork = &ServerNetwork::getInstance();

	// SystemInitListeners
	__pEventBroadcaster->__addSystemInitListener(*__pServerNetwork);
	__pEventBroadcaster->__notifySystemInit();
}

AsyncTaskManager &System::SystemContents::getTaskManager()
{
	return *__pTaskMgr;
}

EventBroadcaster &System::SystemContents::getEventBroadcaster()
{
	return *__pEventBroadcaster;
}

DatabaseManager &System::SystemContents::getDatabaseManager()
{
	return *__pDatabaseManager;
}

ServerNetwork &System::SystemContents::getServerNetwork()
{
	return *__pServerNetwork;
}

void System::SystemContents::__release()
{
	if (__pEventBroadcaster)
	{
		delete __pEventBroadcaster;
		__pEventBroadcaster = nullptr;
	}

	if (__pDatabaseManager)
	{
		delete __pDatabaseManager;
		__pDatabaseManager = nullptr;
	}

	if (__pTaskMgr)
	{
		delete __pTaskMgr;
		__pTaskMgr = nullptr;
	}
}

void System::printLog(const tstring &message)
{
	__pDlg->printLog(message);
}

System& System::getInstance()
{
	return __instance;
}

System::SystemContents& System::getSystemContents()
{
	return __instance.systemContents;
}