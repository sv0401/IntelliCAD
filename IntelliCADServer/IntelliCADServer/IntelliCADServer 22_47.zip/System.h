#pragma once

#include "AsyncTaskManager.hpp"
#include "EventBroadcaster.h"
#include "DatabaseManager.h"
#include "ServerNetwork.h"

class System
{
private:
	friend class CIntelliCADServerApp;
	friend class CIntelliCADServerDlg;

	CIntelliCADServerDlg *__pDlg = nullptr;

	static System __instance;

	System() = default;

	void __setDlgReference(CIntelliCADServerDlg &dlg);

	static void __init();
	static void __release();

public:
	class SystemContents
	{
	private:
		friend System;

		AsyncTaskManager *__pTaskMgr = nullptr;
		EventBroadcaster *__pEventBroadcaster = nullptr;
		DatabaseManager *__pDatabaseManager = nullptr;
		ServerNetwork *__pServerNetwork = nullptr;

		void __init();
		void __release();

	public:
		AsyncTaskManager &getTaskManager();
		EventBroadcaster &getEventBroadcaster();
		DatabaseManager &getDatabaseManager();
		ServerNetwork &getServerNetwork();
	}
	systemContents;

	void printLog(const std::tstring &message);

	static System& getInstance();
	static System::SystemContents& getSystemContents();
};
