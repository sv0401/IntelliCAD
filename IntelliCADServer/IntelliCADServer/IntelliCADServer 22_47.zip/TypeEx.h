#pragma once

using ubyte = unsigned char;
using ushort = unsigned short;
using uchar = unsigned char;
using uint = unsigned int;