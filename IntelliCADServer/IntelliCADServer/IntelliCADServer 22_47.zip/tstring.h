#pragma once

#include <string>
#include <tchar.h>

namespace std
{
	using tstring = basic_string<TCHAR>;
}